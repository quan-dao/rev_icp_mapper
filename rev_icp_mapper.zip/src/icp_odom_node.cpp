#include <ros/ros.h>
#include <tf/transform_broadcaster.h>
#include <tf/transform_listener.h>
#include <sensor_msgs/PointCloud2.h>

#include "pointmatcher/PointMatcher.h"

#include "pointmatcher_ros/point_cloud.h"
#include "pointmatcher_ros/transform.h"

#include <iostream>
#include <fstream>

using namespace std;

class Mapper
{
  typedef PointMatcher<float> PM;
	typedef PM::DataPoints DP;

public:
  Mapper(ros::NodeHandle nh_, ros::NodeHandle nh_private_);
  ~Mapper();

protected:
  void cloudCallBack(const sensor_msgs::PointCloud2::ConstPtr& cloud_msg);
  void publishAll(ros::Time stamp);
  DP* updateMap(DP* newPointCloud, const PM::TransformationParameters Ticp, bool updateExisting);
  void setMap(DP* newPointCloud);

protected:
  ros::NodeHandle& nh, nh_private;

  // Subscriber
  ros::Subscriber cloudSub;

  // Publisher
  ros::Publisher cloudMergedPub;

  tf::TransformBroadcaster tfBroadcaster;
  tf::TransformListener tfListener;

  PM::DataPointsFilters inputFilters;
	PM::DataPointsFilters mapPreFilters;
	PM::DataPointsFilters mapPostFilters;
	PM::DataPoints *mapPointCloud;
	PM::ICPSequence icp;
  shared_ptr<PM::Transformation> transformation;

  PM::TransformationParameters T_velo_to_map;  // odometry is performed for velo_link

  // Parameters
  int minReadingPointCount;
	int minMapPointCount;
  double minOverlap;
	double maxOverlapToMerge;
  int startUpDropOut;  // number of pointcloud dropped at startup
  int dropOutCounter;
  string mapFrameId;
};


Mapper::Mapper(ros::NodeHandle nh_, ros::NodeHandle nh_private_) :
  nh(nh_),
  nh_private(nh_private_),
  mapPointCloud(0),
  transformation(PM::get().REG(Transformation).create("RigidTransformation")),
  T_velo_to_map(PM::TransformationParameters::Identity(4, 4)),
  minReadingPointCount(2000),
  minMapPointCount(500),
  minOverlap(0.5),
  maxOverlapToMerge(0.9),
  startUpDropOut(1),
  dropOutCounter(0),
  mapFrameId("map")
{
  // load config
  string configFilename;
  if(ros::param::get("~icpConfig", configFilename)) 
  {
    ifstream ifs(configFilename.c_str());
    if(ifs.good()) 
    {
      icp.loadFromYaml(ifs);
    } else {
      ROS_ERROR_STREAM("Cannot load ICP config from YAML file: "<<configFilename);
      icp.setDefault();
    }
  }
  else
  {
    ROS_WARN("Not using ICP config file. Use default config");
    icp.setDefault();
  }

  if(ros::param::get("~inputFiltersConfig", configFilename)) 
  {
    ifstream ifs(configFilename.c_str());
    if(ifs.good()) 
    {
      inputFilters = PM::DataPointsFilters(ifs);
    } else {
      ROS_ERROR_STREAM("Cannot load input filters config from YAML file: "<<configFilename);
    }
  }
  else
  {
    ROS_WARN("Not using input filters");  
  }
  
  if(ros::param::get("~mapPreFiltersConfig", configFilename)) 
  {
    ifstream ifs(configFilename.c_str());
    if(ifs.good()) 
    {
      mapPreFilters = PM::DataPointsFilters(ifs);
    } else {
      ROS_ERROR_STREAM("Cannot load map pre filters config from YAML file: "<<configFilename);
    }
  }
  else
  {
    ROS_WARN("Not using map pre filters");  
  }

  if(ros::param::get("~mapPostFiltersConfig", configFilename)) 
  {
    ifstream ifs(configFilename.c_str());
    if(ifs.good()) 
    {
      mapPostFilters = PM::DataPointsFilters(ifs);
    } else {
      ROS_ERROR_STREAM("Cannot load map post filters config from YAML file: "<<configFilename);
    }
  }
  else
  {
    ROS_WARN("Not using map post filters");  
  }
  
  // topic init
  cloudSub = nh.subscribe("cloud_in", 1, &Mapper::cloudCallBack, this);
  cloudMergedPub = nh.advertise<sensor_msgs::PointCloud2>("merged_cloud", 1);

  // get params
  nh_private.param("minReadingPointCount", minReadingPointCount, minReadingPointCount);
  nh_private.param("minMapPointCount", minMapPointCount, minMapPointCount);
  nh_private.param("minOverlap", minOverlap, minOverlap);
  nh_private.param("maxOverlapToMerge", maxOverlapToMerge, maxOverlapToMerge);
  nh_private.param("startUpDropOut", startUpDropOut, startUpDropOut);
  nh_private.param("mapFrameId", mapFrameId, mapFrameId);
};


Mapper::~Mapper()
{
  if (mapPointCloud)
    delete mapPointCloud;
}


Mapper::DP* Mapper::updateMap(DP* newPointCloud, const PM::TransformationParameters Ticp, bool updateExisting)
{
	// Correct new points using ICP result
	*newPointCloud = transformation->compute(*newPointCloud, Ticp); 
	
	// Preparation of cloud for inclusion in map
	mapPreFilters.apply(*newPointCloud);
	
	// Merge point clouds to map
	if (updateExisting)
		newPointCloud->concatenate(*mapPointCloud);

	// Map maintenance
	if(newPointCloud->features.cols() > minMapPointCount)
		mapPostFilters.apply(*newPointCloud);
	
	ROS_INFO_STREAM("New map available (" << newPointCloud->features.cols() << " pts)");
	
	return newPointCloud;
}

void Mapper::setMap(DP* newPointCloud)
{
	// delete old map
	if (mapPointCloud)
		delete mapPointCloud;
	
	// set new map
	mapPointCloud = newPointCloud;
	icp.setMap(*mapPointCloud);	
}


void Mapper::cloudCallBack(const sensor_msgs::PointCloud2::ConstPtr& cloud_msg)
{
  // drop start up point cloud
  if (dropOutCounter < startUpDropOut) 
  {
    ROS_INFO("Dropping pointcloud at startup");
    dropOutCounter++;
    return;
  }
  
  // convert ros msg to PointMatcher cloud
  unique_ptr<Mapper::DP> newPointCloud (new Mapper::DP(PointMatcher_ros::rosMsgToPointMatcherCloud<float>(*cloud_msg)));

  if (dropOutCounter == startUpDropOut) 
  {
    ROS_INFO("Initialize merged pointcloud with current scan");
    setMap(updateMap(newPointCloud.get(), T_velo_to_map, false));
    dropOutCounter++;
    publishAll(cloud_msg->header.stamp); 
    return;
  }

  /// preprocess reading cloud
  const size_t goodCount (newPointCloud->features.cols());
  if (goodCount==0) {
    ROS_ERROR("Find no good point in the current cloud. Ignore incoming cloud");
    return;
  }

  // ensure minimum amount of points before filtering
  int ptsCount = newPointCloud->getNbPoints();
  if (ptsCount < minReadingPointCount) {
    ROS_ERROR_STREAM("Not enough points in newPointCloud: only " << ptsCount << " / "<<minReadingPointCount <<" pts");
    return;
  }

  // apply filter to reading cloud
  inputFilters.apply(*newPointCloud.get());
  
  // ensure minimum amount of points before filtering
  ptsCount = newPointCloud->getNbPoints();
  if (ptsCount < minReadingPointCount) {
    ROS_ERROR_STREAM("Not enough points in newPointCloud: only " << ptsCount << " / "<<minReadingPointCount <<" pts");
    return;
  }

  // apply ICP
  try {
    PM::TransformationParameters Ticp;
    Ticp = icp(*newPointCloud.get(), T_velo_to_map);

    // ensure minimum overlap between scans
		const double estimatedOverlap = icp.errorMinimizer->getOverlap();
		ROS_INFO_STREAM("Overlap: " << estimatedOverlap);
		if (estimatedOverlap < minOverlap)
		{
			ROS_ERROR_STREAM("Estimated overlap too small, ignoring ICP correction!");
			return;
		}

    // update T_velo_to_map
    T_velo_to_map = Ticp;

    // merge reading cloud to current map
   if ((estimatedOverlap < maxOverlapToMerge) || (icp.getPrefilteredInternalMap().features.cols() < minMapPointCount))
   {
     ROS_INFO("Adding new points to the map");
     setMap(updateMap( newPointCloud.get(), Ticp, true));
   }
  } 
  catch (PM::ConvergenceError error) {
    ROS_ERROR_STREAM("ICP failed to converge: " << error.what());
		return;
  }

  publishAll(cloud_msg->header.stamp);
}


void Mapper::publishAll(ros::Time stamp)
{
  sensor_msgs::PointCloud2 cloud_out = PointMatcher_ros::pointMatcherCloudToRosMsg<float>(icp.getInternalMap(), mapFrameId, stamp);
  cloudMergedPub.publish(cloud_out);
}



int main(int argc, char** argv) 
{
  ros::init(argc, argv, "icp_odom_node");
  ros::NodeHandle nh_, nh_private_("~");
  Mapper mapper_node(nh_, nh_private_);
  ros::spin();
}